// alert(1)

// const _ = 'private'
// const if = 'mkef'
// prompt('введите')

const a = 10
const b = 5

console.log(a+b)